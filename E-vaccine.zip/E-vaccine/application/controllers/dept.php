<?php 
class Dept extends MY_Controller
{       
    public function dashboard()
    {
        $this->load->view('department/home');
    }
    public function feedback()
    {
        $this->load->model('dept_model');
        $fback=$this->dept_model->feedback();
        $this->load->view('department/feedback',['fback'=>$fback]);
    }
    public function addcenters()
    {
        $this->load->model('dept_model');
        $cities=$this->dept_model->getcities();
        $pin=$this->dept_model->getpincode();
        $this->load->view('department/add_center',['cities'=>$cities,'pin'=>$pin]);
    }
    public function add_center()
    {       
        $this->form_validation->set_rules('c_name', 'Center', 'required');
        $this->form_validation->set_rules('vaccine_name', 'Vaccine', 'required');
        $this->form_validation->set_rules('Pincode', 'Pincode', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('date', 'Date', 'required');
        $this->form_validation->set_rules('time_slot', 'Time Slot', 'required');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');
        if($this->form_validation->run()){
            $data=$this->input->post();
            $this->load->model('dept_model');
           
           //echo '<pre>';
            //print_r($center);
            //echo '</pre>';
             $center=$this->dept_model->newcenter($data);
            if($center){
                    echo "<script>alert('Vaccine Center added successfully.....');document.location='http://localhost/E-vaccine/dept/add_center'</script>";
               
            }else{
                    echo "<script>alert('Failed to add Vaccine Center...Try again');document.location='http://localhost/E-vaccine/dept/add_center'</script>";
                }
        }else{
            $this->addcenters();
        }
    }
    public function addcity()
    {
        $this->load->model('dept_model');
        $this->load->view('department/addcity');
    }
    public function add_city()
    {
        
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');
        if($this->form_validation->run())
        {
            $addcity=$this->input->post();
            $this->load->model('dept_model');
            if($this->dept_model->addcities($addcity))
            {
                echo "<script>alert('City added successfully.....');document.location='http://localhost/E-vaccine/dept/add_city'</script>";
               
            }
            else{
                echo "<script>alert('Failed to add City.....Try Again !!');document.location='http://localhost/E-vaccine/dept/add_city'</script>";
            }
        }
        else{
            $this->addcity();
        }
    }
    public function verify(){
        $this->load->model('dept_model');
        $appointments=$this->dept_model->ver_appointments();
        $this->load->view('department/verify',['appointments'=>$appointments]);
    }
    public function search_pin(){
        $this->load->model('dept_model');
        $pin=$this->dept_model->getpincode();
        $this->load->view('pincode',['pin'=>$pin]);
    }
    public function search_city(){
        $this->load->model('dept_model');
        $cities=$this->dept_model->getcities();
        $this->load->view('city',['cities'=>$cities]);
    }
    public function cancel($reference_id)
    {
        $this->load->model('dept_model');
        if($this->dept_model->cancel($reference_id))
        {
            echo "<script>alert('Appointment cancelled successfully');document.location='http://localhost/E-vaccine/dept/verify'</script>";
        }
    }
    public function save($reference_id)
    {  
        $this->load->model('dept_model');
        if($this->dept_model->saved($reference_id))
        {
            echo "<script>alert('Verified successfully');document.location='http://localhost/E-vaccine/dept/verify'</script>";
        }
    }
    public function __construct()
    {
        parent::__construct();
        if(!$this->session->userdata("dept_id"))
        return redirect("home/deptlogin");
    }
  
}