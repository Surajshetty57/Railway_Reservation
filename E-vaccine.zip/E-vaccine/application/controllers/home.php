<?php
class Home extends MY_Controller {

	public function index()
	{
		$this->load->view('home');
	}
	public function newregister()
    {   
        if($this->session->userdata("user_id")){
            redirect("user/dashboard");
        }else{
            $this->load->view('userregister');
        }
    }
	public function register()
    {
        $this->form_validation->set_rules('fname', 'Fullname', 'required|min_length[5]|max_length[42]|trim|alpha_numeric_spaces');
        $this->form_validation->set_rules('uname', 'Username', 'trim|required|min_length[5]|max_length[12]|is_unique[user.uname]');
        $this->form_validation->set_rules('dob', 'Date of birth', 'required');
        $this->form_validation->set_rules('gender', 'Gender', 'required');
        $this->form_validation->set_rules('mobile', 'Mobile Number', 'trim|required|max_length[10]|min_length[10]');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('pword', 'Password', 'trim|required|min_length[8]');
        $this->form_validation->set_rules('cpword', 'Confirm Password', 'trim|required|min_length[8]|matches[pword]');
        $this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');
  
      if($this->form_validation->run()){
          $pdata=array(
              'user_id' => '', 
              'fname'        => $this->input->post('fname'),
              'uname'        => $this->input->post('uname'),   
              'dob'          => $this->input->post('dob'),
              'gender'       => $this->input->post('gender'),
              'mobile'       => $this->input->post('mobile'),
              'city'         => $this->input->post('city'),
              'pword'        => sha1($this->input->post('pword')),
              'cpword' => sha1($this->input->post('cpword'))
          );
          $this->load->model('user_model');
          $dbId = $this->user_model->user_validate($pdata); 
  
        if($dbId)
        {   
            $pdata['user_id'] = $dbId;
            $this->session->set_userdata($pdata);
            $this->session->set_flashdata('message','You have successfully registered to SS Travels... ');
            redirect('user/dashboard');
        } 
        else{
            $this->session->set_flashdata('message','Sorry failed to register');
            
            redirect('home/register');
        }
    }
    else{
            $this->newregister();
        }
    }
    public function reg_logout()
    {   
        $this->session->unset_userdata("user_id");
        return redirect('home'); 
    }
    public function ulogin()
        {
            if($this->session->userdata("user_id"))
            return redirect("user/dashboard");
            $this->load->view('userlogin');
        }
    
    public function Uslogin()
    {       
        $this->form_validation->set_rules('uname', 'Username', 'trim|required|min_length[5]|max_length[12]');
        $this->form_validation->set_rules('pword', 'Password', 'trim|required|min_length[8]'); 
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');
        if($this->form_validation->run())
        {
            $uname = $this->input->post('uname');
            $pword = sha1( $this->input->post('pword'));
            $this->load->model('user_model');
            $userExist =$this->user_model->user_validation($uname,$pword);
            /*echo '<pre>';
            print_r($userExist);
            echo '</pre>';*/
            if( $userExist){
                $userData= [
                    'user_id' => $userExist->user_id,
                    'uname' => $userExist->uname,
                    'pword' => $userExist->pword,
                ];
                $this->session->set_userdata($userData);
                return redirect('user/dashboard');
            }else{
                echo "<script>alert('Invalid Username or Password.Try again !!!');document.location='http://localhost/E-vaccine/home/ulogin'</script>";
            }
        }else{
            $this->ulogin();
        }
    }
    public function ulogout()
    {   
        $this->session->unset_userdata("user_id");
        return redirect("home"); 
    }
    
    public function search_city(){
        $this->load->model('user_model');
        $cities=$this->user_model->getcities();
        $this->load->view('city',['cities'=>$cities]);
    }
    public function availableslots()
    {
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('date', 'date', 'trim|required|min_length[5]');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');
        if($this->form_validation->run())
        {
            $this->load->model('user_model');
            $city=$this->input->post('city');
            $date=$this->input->post('date');
            $results=$this->user_model->view_slots_city($city,$date);
            /*echo '<pre>';
            print_r($results);
            echo '</pre>'; */
                if($results)
                {
                    $this->load->view('available_slots',['showslots'=>$results]);
                }
                else{ 
                    echo "<script>alert('No Centers available on particular date');document.location='http://localhost/E-vaccine/home/search_city'</script>";
                }
        } else{
            $this->search_city();
        }
    }
    public function search_pin(){
        $this->load->model('user_model');
        $pin=$this->user_model->getpincode();
        $this->load->view('pincode',['pin'=>$pin]);
    }
    public function availableslot()
    {
        $this->form_validation->set_rules('pincode', 'Pincode', 'required');
        $this->form_validation->set_rules('date', 'date', 'trim|required|min_length[5]');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');
        if($this->form_validation->run())
        {
            $this->load->model('user_model');
            $pin=$this->input->post('pincode');
            $date=$this->input->post('date');
            $results=$this->user_model->view_slots_pin($pin,$date);
            /*echo '<pre>';
            print_r($results);
            echo '</pre>'; */
                if($results)
                {
                    $this->load->view('available_slots',['showslots'=>$results]);
                }
                else{ 
                    echo "<script>alert('No Centers available on particular date');document.location='http://localhost/E-vaccine/home/search_pin'</script>";
                }
        } else{
            $this->search_pin();
        }
    }
    public function contact()
    {
        $this->load->view('feedback');
    } 
    public function contactus()
    {
        $this->form_validation->set_rules('name', 'Name', 'required|min_length[5]|max_length[30]|trim|alpha_numeric_spaces');
        $this->form_validation->set_rules('mobile', 'Mobile Number', 'trim|required|max_length[10]|min_length[10]');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email'); 
        $this->form_validation->set_rules('feedback', 'Feedback', 'required|min_length[10]|max_length[1000]|trim');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');

        if($this->form_validation->run()){
            $this->load->model('user_model');
            $feedback=array(
                'name'=>$this->input->post('name'),
                'mobile'=>$this->input->post('mobile'),
                'email'=>$this->input->post('email'), 
                'feedback'=>$this->input->post('feedback')
            );
            if($this->user_model->send_feedback($feedback)){
                $this->session->set_userdata($feedback);
                echo "<script>alert('Feedback Sent successfully... ');document.location='http://localhost/E-vaccine/home/contact'</script>";
           
            }
            else{
                echo "<script>alert('Failed to send your feedback...');document.location='http://localhost/E-vaccine/home/contact'</script>";
           
            }
        }
        else{
                $this->contact();
            }
    
    }
    public function signin()
    {
        $this->load->view('deptlogin');
    }
    
    public function deptlogin()
    {       
        $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]|max_length[20]|alpha');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');
        if($this->form_validation->run())
        {
            $username = $this->input->post('username');
            $password = sha1( $this->input->post('password'));
            $this->load->model('dept_model');
            $adminexist =$this->dept_model->dept_validate($username,$password);
           /* echo '<pre>';
            print_r($adminexist);
            echo '</pre>';*/
            if( $adminexist){
                $sessionData= [
                    'dept_id' => $adminexist->dept_id,
                    'username' => $adminexist->username,
                ];
                $this->session->set_userdata($sessionData);
                return redirect('dept/dashboard');
            }else{
                echo "<script>alert('Invalid Username or Password.Try again !!!');document.location='http://localhost/E-vaccine/home/deptlogin'</script>";
            }
        }
        else{
            $this->signin();
        }

    }		
    public function logout()
    {   
        $this->session->unset_userdata("dept_id");
        return redirect("home/deptlogin");
    }
    
}
?>