<?php
class User extends MY_Controller {

	public function dashboard()
	{
		$this->load->view('userhome');
	}
	public function details()
    {
        $this->load->model('user_model');
        $data=$this->user_model->fetchdetails($this->session->userdata('user_id'));
        $this->load->view('details',['data'=>$data]);
    }
    public function search_pin(){
        $this->load->model('user_model');
        $pin=$this->user_model->getpincode();
        $this->load->view('pincode',['pin'=>$pin]);
    }
    public function search_city(){
        $this->load->model('user_model');
        $cities=$this->user_model->getcities();
        $this->load->view('city',['cities'=>$cities]);
    }
    public function book_by_city(){
        $this->load->model('user_model');
        $cities=$this->user_model->getcities();
        $this->load->view('book_by_city',['cities'=>$cities]);
    }
    public function availableslots()
    {
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('date', 'date', 'trim|required|min_length[5]');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');
        if($this->form_validation->run())
        {
            $this->load->model('user_model');
            $city=$this->input->post('city');
            $date=$this->input->post('date');
            $results=$this->user_model->view_slots_city($city,$date);
            /*echo '<pre>';
            print_r($results);
            echo '</pre>'; */
                if($results)
                {
                    $this->load->view('slots_available',['showslots'=>$results]);
                }
                else{ 
                    echo "<script>alert('No Centers available on particular date');document.location='http://localhost/E-vaccine/user/book_by_city'</script>";
                }
        } else{
            $this->book_by_city();
        }
    }
    public function book_by_pin(){
        $this->load->model('user_model');
        $pin=$this->user_model->getpincode();
        $this->load->view('book_by_pin',['pin'=>$pin]);
    }
    public function availableslot()
    {
        $this->form_validation->set_rules('pincode', 'Pincode', 'required');
        $this->form_validation->set_rules('date', 'date', 'trim|required|min_length[5]');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');
        if($this->form_validation->run())
        {
            $this->load->model('user_model');
            $pin=$this->input->post('pincode');
            $date=$this->input->post('date');
            $results=$this->user_model->view_slots_pin($pin,$date);
            /*echo '<pre>';
            print_r($results);
            echo '</pre>'; */
                if($results)
                {
                    $this->load->view('slots_available',['showslots'=>$results]);
                }
                else{ 
                    echo "<script>alert('No Centers available on particular date');document.location='http://localhost/E-vaccine/user/book_by_pin'</script>";
                }
        } else{
            $this->book_by_pin();
        }
    }
    public function bookslots($c_id)
    {
        $this->load->model('user_model');
        $cities=$this->user_model->getcities();
        $pin=$this->user_model->getpincode();
        $showslots=$this->user_model->get_slot_details($c_id);
        $data=$this->user_model->fetch_slot($this->session->userdata('user_id'));
        $this->load->view('bookslots',['showslots'=> $showslots,'cities'=>$cities,'pin'=>$pin,'data'=>$data]);    
    }
    public function take_appointment($c_id)
    {
        $this->load->model('user_model');
        $this->form_validation->set_rules('user_id', 'User ID', 'required');
        $this->form_validation->set_rules('booked_by', 'Booked By', 'required');
        $this->form_validation->set_rules('c_name', 'Center', 'required');
        $this->form_validation->set_rules('vaccine_name', 'Vaccine', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('date', 'Date', 'required');
        $this->form_validation->set_rules('time_slot', 'Time', 'required');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');

        $data=$this->user_model->fetch_slot($this->session->userdata('user_id'));
        if($this->form_validation->run()){
            $data= array(
                'reference_id'=>$this->input->post('reference_id'),
                'booked_by'=>$this->input->post('booked_by'),
                'user_id'=>$this->input->post('user_id'),
                'c_name'=>$this->input->post('c_name'),
                'vaccine_name'=>$this->input->post('vaccine_name'),
                'city'=>$this->input->post('city'),
                'date'=>$this->input->post('date'),
                'time_slot'=>$this->input->post('time_slot')
            );
            $this->load->model('user_model');
            if($this->user_model->bookslots($data,$c_id)){
                $a=array(
                    'reference_id'=>$this->input->post('reference_id'),
                    'c_name'=>$this->input->post('c_name'),
                    'vaccine_name'=>$this->input->post('vaccine_name'),
                    'city'=>$this->input->post('city'),
                    'date'=>$this->input->post('date'),
                    'time_slot'=>$this->input->post('time_slot')
                );
                $this->session->set_userdata($a);
                echo "<script>alert('Appointment Confirmed !!!');document.location='http://localhost/E-vaccine/user/dashboard'</script>";
            }
            else{
                echo "<script>alert('Sorry..Couldn't get appointment..Try again !!!');document.location='http://localhost/E-vaccine/user/'</script>";
            }
        }else{
            $this->bookslots($c_id);
        }
    }
    public function cpword()
    {
        $this->load->view('changepassword');
    }
    public function changepassword()
    {
        $this->form_validation->set_rules('pword', 'Current Password', 'trim|required|min_length[8]');
        $this->form_validation->set_rules('npword', 'New Password', 'trim|required|min_length[8]');
        $this->form_validation->set_rules('confirmnpword', 'Confirm New Password', 'trim|required|min_length[5]|alpha_numeric|matches[npword]');
        $this->form_validation->set_error_delimiters('<p class="text-primary">','</p>');

        if($this->form_validation->run()){
            
            $data=array(
                'pword'=>sha1($this->input->post('npword'))
            );
            $this->load->model('user_model');

            //print_r($data);exit();
            $result=$this->user_model->checkoldpword($this->session->userdata('user_id'),sha1($this->input->post('pword')));
           // var_dump($result);
            if($result >0 AND $result==true){
                $result=$this->user_model->update_userdata($this->session->userdata('user_id'),$data);
                if($result>0)
                {
                    echo "<script>alert('Password Changed Successfully');document.location='http://localhost/E-vaccine/user/changepassword'</script>";
                
                }else{
                    echo "<script>alert('Failed to Update Password!! Try again');document.location='http://localhost/E-vaccine/user/changepassword'</script>";
                
                }
            }else{
                echo "<script>alert('Old Password is not Correct!! Try again');document.location='http://localhost/E-vaccine/user/changepassword'</script>";
                
            }
        }
        else{
                $this->cpword(); 
            }
    }
    public function download($user_id=0){
        $this->load->model('user_model');
        $show_cert=$this->user_model->certificate_details($this->session->userdata('user_id'));
        $this->load->view('download',['show_cert'=>$show_cert]);
    }
    public function __construct()
    {
        parent::__construct();
        if(!$this->session->userdata("user_id"))
        return redirect("home");

    }
}
?>