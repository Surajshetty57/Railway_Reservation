

    <style>
    .nav-link {
        font-size: 25px; 
        margin-left:20px; }  
    a{
        font-size: 23px;
        text-align:center;
        font-family:Monotype Corsiva; }
    h1{
        font-size: 45px;
        font-family:Monotype Corsiva;
        }
        
    </style>
 </head>
 <?php include_once 'dept_dashboard.php';?>
<body>


<div class="container" >
<h1  style="color:whitesmoke;text-decoration:underline;margin-top:30px;margin-bottom:40px">Feedback Of the User</h2>
<table class="table table-hover " style="text-align:center;color:whitesmoke;"><b>
  <thead>
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Mobile Number</th>
      <th scope="col">E-mail</th>
      <th scope="col">Feedback</th>
    </tr>
  </thead>
  <tbody>
  <?php if(count($fback)):?>
    <?php foreach($fback as $fb): ?>
    <tr scope="col">
      <td ><?php echo $fb->name; ?></td>
      <td><?php echo $fb->mobile; ?></td>
      <td><?php echo $fb->email; ?></td>
      <td><?php echo $fb->feedback; ?></td>
    </tr>
    <?php endforeach;?>
  <?php else:?>
    echo "<script>alert('No feedback from the user yet.....');document.location='http://localhost/E-vaccine/dept/dashboard'</script>";
               
  <?php endif;?>
  </tbody>
</table>
</body>
</html>



