
 <?php include_once 'dept_dashboard.php';?>
<body>
<div class="container">
<h1 style="font-family:monotype corsiva;font-size:45px;color:whitesmoke;text-decoration:underline;margin-top:50px">All Appointments </h1><br>

<div class="d-flex justify-content-center ">
<table class="table table-type " style="text-align:center;margin-top:20px">
  <thead>
    <tr>
      <th scope="col">Reference Id</th>
      <th scope="col">Booked By</th>
      <th scope="col">User ID</th>
      <th scope="col">Center</th>
      <th scope="col">Vaccine Name</th>
      <th scope="col">City</th>
      <th scope="col">Date</th>
      <th scope="col">Time Slot</th>
      <th scope="col">Action</th>
    </tr>
  </thead>     
  <tbody>
  <?php if(count($appointments)):?>
    <?php foreach($appointments as $verified): ?>
    <tr class="table-type">
      <td ><?php echo $verified->reference_id; ?></td>
      <td ><?php echo $verified->booked_by; ?></td>
      <td ><?php echo $verified->user_id; ?></td>
      <td ><?php echo $verified->c_name; ?></td>
      <td ><?php echo $verified->vaccine_name; ?></td>
      <td ><?php echo $verified->city; ?></td>
      <td ><?php echo $verified->date; ?></td>
      <td ><?php echo $verified->time_slot; ?></td>
      <td >
            <?php echo anchor("dept/save/{$verified->reference_id}",'Verify',['class'=>'btn btn-outline-primary','style'=>'font-size:13px;height:23px;width:40%;padding-top :0px;text-align:center']); ?>
            <?php echo anchor("dept/cancel/{$verified->reference_id}",'Cancel',['class'=>'btn btn-outline-danger','style'=>'font-size:13px;height:23px;width:40%;padding-top :0px;text-align:center']); ?>
      </td>
    </tr>
    <?php endforeach;?>
  <?php else:?>
        <script>alert('No appointments taken yet');document.location='http://localhost/E-vaccine/dept/dashboard'</script>
  <?php endif;?>
  </tbody>
</table>
