<style>
  h1{
    text-align:center;
    font-family:monotype corsiva;
    color:whitesmoke;  
    font-size:55px;
  }
</style>
<?php include_once 'dept_dashboard.php';?><br>

<h1 style="margin-top:200px; ">
<b>Welcome</h1>
<h1> Get started with Verifying Appointments</b></h1> <br>
</div>