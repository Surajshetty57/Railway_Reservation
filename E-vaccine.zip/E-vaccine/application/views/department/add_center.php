
    <style>
.border-class
{
  width:35%;
}
.form-group{
  padding-top: 10px;
}
label{
  padding-top:10px;
}
</style>
 </head>
 <?php include_once 'dept_dashboard.php';?>
<div class="d-flex justify-content-center">
 <div class="border-class" >
<div class="container">
  <div class="card border-dark mb-3" style="margin-top:30px;">
    <div class="card-body">
      <?php echo form_open('dept/add_center');?>
        <form method="post" name="addcenter" action="<?php echo base_url('dept/add_center');?>">
          <fieldset>
          <h1 style="font-family:monotype corsiva;font-size:45px;color:whitesmoke;text-decoration:underline;">Add Vaccine Center </h1><br>
          <div class="col-lg-12">
              <div class="form-grou">
                <label style="padding-top:0px;">Center</label>
                <?php echo form_input(['type'=>'input','name'=>'c_name','class'=>'form-control','placeholder'=>'Enter Center']); ?>
                <?php echo form_error('c_name'); ?>
              </div>
              <div class="form-group">
                <label for="Vaccine Name"  >Vaccine Name</label>
                <select class="form-select" id="exampleSelect1" name="vaccine_name">
                <option>Covaxin</option>
                <option>Covishield</option>
                <option>Sputnik</option>
                </select>
                <?php echo form_error('Vaccine'); ?>
                </div>
              <div class="form-group" >
                <label for="pincode">Pincode</label>
                <select class="form-control" id="exampleSelect" name="Pincode" > 
                <?php if(count($pin)):?>
                <?php foreach($pin as $pin_code):?>
                <option value=<?php echo $pin_code->pincode?>><?php echo $pin_code->pincode?> </option>
                <?php endforeach;?>
                <?php endif;?>
                </select>
                <?php echo form_error('Pincode'); ?>
              </div>
              <div class="form-group" >
                <label for="city">City</label>
                <select class="form-control" id="exampleSelect" name="city"> 
                  <?php if(count($cities)):?>
                  <?php foreach($cities as $city_):?>
                  <option value=<?php echo $city_->city?>><?php echo $city_->city?> </option>
                  <?php endforeach;?>
                  <?php endif;?>
                </select><?php echo form_error('city'); ?>
              </div>
              <div class="form-group">
                <label for="Date">Date</label>
                <?php echo form_input(['type'=>'date','name'=>'date','class'=>'form-control','value'=>set_value('date')]); ?>
                <?php echo form_error('date'); ?>
              </div>
              <div class="form-group">
                <label for="Time SLot"  >Time SLot</label>
                <select class="form-select" id="exampleSelect1" name="time_slot">
                <option>09:00 AM - 11:00 AM</option>
                <option>11:00 AM - 01:00 PM</option>
                <option>02:00 PM - 04:00 PM</option>
                </select>
                <?php echo form_error('time_slot'); ?>
                </div>
              
              <button type="submit" class="btn btn-primary" style="margin-top:15px">Add Center</button>
            </div>
        </fieldset>
        </form>
      </div>
    </div>
  </div>
</div><br><br>

