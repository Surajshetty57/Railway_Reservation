<style>
.border-class
{
  width:30%;
  margin-top:7%;
}
.form-group{
  padding: 10px;
}
</style>
<?php include_once 'dept_dashboard.php';?>
<div class="d-flex justify-content-center">
<div class="border-class" >
<div class="container">
  <div class="card border-dark mb-3" style="margin-top:30px;">
    <div class="card-body">
    <?php echo form_open('dept/add_city');?>
      <form >
        <fieldset>
          <h2 style="font-family:monotype corsiva;font-size:45px;color:whitesmoke;text-decoration:underline;">Add City </h2>
         
          <div class="form-group"><b>
            <label >City</label>
              <?php echo form_input(['name'=>'city','class'=>'form-control','placeholder'=>'Enter City','value'=>set_value('city')]); ?>
	            <?php echo form_error('city'); ?>
          </div>
          <div style="padding:15px">
            <button type="submit" class="btn btn-primary" value="login">Submit</button>
            <button type="reset" class="btn btn-warning" >Cancel</button>
          </div>
          </fieldset>
        </fieldset>
        </div>
      </form>
</div>
</div>
       


