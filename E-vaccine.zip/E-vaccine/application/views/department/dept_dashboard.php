<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Vaccine - Department</title>
    <style>
    .nav-link{
        font-size: 25px;
        font-family:monotype corsiva;  
        margin-left:35px;
    }
  
</style>
    
</head>
<link rel="stylesheet" href="<?= base_url('vaccine\css\bootstrap.css'); ?>">
<link rel="stylesheet" href="<?= base_url('vaccine\css\dropdown.css'); ?>">

<body style="background-color:">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">

    <div class="collapse navbar-collapse" id="navbarColor02">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" href="<?= base_url('dept/dashboard') ?>">Home</a>
        </li>
        </li>
        <li class="nav-item">
        <div class="dropdown">
          <a class="nav-link active" >Add</a>
            <div class="dropdown-content">
              <a style="font-family:monotype corsiva;font-size: 20px;" href="<?= base_url('dept/add_center') ?>">Vaccine Centers</a>
              <a style="font-family:monotype corsiva;font-size: 20px;" href="<?= base_url('dept/add_city') ?>">Cities</a>
            </div>
        </div>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="<?= base_url('dept/feedback') ?>">Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="<?= base_url('dept/verify') ?>">Verify</a>
        </li>
        
      </ul>
      <a class="btn btn-primary btn-sm" style="font-size:px;font-family:Monotype Corsiva;color:whitesmoke;" href="<?= base_url('home/logout') ?>">Logout</a>
    </div>
  </div>
</nav>
    
</body>
</html>