
<style>
.border-class
{
  width:30%;
  margin-top:7%;
}
.form-group{
  padding: 10px;
}
</style>
<?php include('common/header.php')?>
<div class="d-flex justify-content-center">
  
<div class="border-class" >
<div class="container">
  <div class="card border-dark mb-3" style="margin-top:30px;">
    <div class="card-body">
    <?php echo form_open('home/deptlogin');?>
      <form >
        <fieldset>
          <h2 style="font-family:monotype corsiva;font-size:45px;color:whitesmoke;text-decoration:underline;">Department Login</h2>
         
          <div class="form-group"><b>
              <label for="username">Username</label>
              <?php echo form_input(['type'=>'username','name'=>'username','class'=>'form-control','placeholder'=>'Enter Username','value'=>set_value('username')]); ?>
	            <?php echo form_error('username'); ?>
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <?php echo form_input(['type'=>'password','name'=>'password','class'=>'form-control','placeholder'=>'Enter Password']); ?>
	            <?php echo form_error('password'); ?>
            </div>
          <div style="padding:10px">
            <button type="submit" class="btn btn-primary" value="login">Submit</button>
            <button type="reset" class="btn btn-warning" >Cancel</button>
          </div>
        </fieldset>
        </div>
      </form>
</div>
</div>
       




