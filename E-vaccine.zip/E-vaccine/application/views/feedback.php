<style>
.border-class
{
  width:30%;
}
.form-group{
  padding: 10px;
}
</style>
<?php include('common/header.php')?><br><br>
<?php echo form_open('home/contactus');?>
    <div class="d-flex justify-content-center">
<div class="border-class" >
<div class="container">
  <div class="card border-dark mb-3" style="margin-top:">
    <div class="card-body">
                    <h2 style="font-family:Monotype Corsiva;font-size:50px;color:whitesmoke;text-decoration:underline;"><b>Feedback</b></h2>
                        <div class="form-group"><b>
                            <label for="name">Name</label>
                            <?php echo form_input(['type'=>'name','name'=>'name','class'=>'form-control','placeholder'=>'Enter Name','value'=>set_value('name')]); ?>
	                        <?php echo form_error('name'); ?>
                        </div>
                        <div class="form-group">
                            <label >Mobile Number</label>
                            <?php echo form_input(['type'=>'number','name'=>'mobile','class'=>'form-control','placeholder'=>'Enter 10 digit Mobile number','value'=>set_value('mobile')]); ?>
	                        <?php echo form_error('mobile'); ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email address</label>
                            <?php echo form_input(['type'=>'email','name'=>'email','class'=>'form-control','id'=>'exampleInputEmail1','aria-describedby'=>'emailHelp','placeholder'=>'Enter email','value'=>set_value('email')]); ?>
                            <?php echo form_error('email'); ?>  
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleTextarea">Feedback</label>
                            <?php echo form_textarea(['name'=>'feedback','class'=>'form-control','id'=>'exampleTextarea','rows'=>'3','placeholder'=>'Write your feedback','value'=>set_value('feedback')]); ?>
                            <?php echo form_error('feedback'); ?> 
                        <button type="submit" style="margin-top:15px"class="btn btn-primary" value="login">Send Feedback</button>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </th>
