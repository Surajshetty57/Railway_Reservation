<style>
  h2{
    font-family:monotype corsiva;
    color:whitesmoke;
    text-decoration:underline;
    text-align:center;
  }
</style>

<?php include('common/header.php')?><br>

<h2 style="font-size:45px;margin-top:50px;">Steps to Get Your appointment</h2><br>
<table >
  <thead>
    <tr>
      <th style=" padding:50px;text-align:center;padding-left:100px;">
        <img style="height: 200px; width: 60%;border-radius:50%;border:2px solid yellow" src="<?= base_url('vaccine\img\download.png'); ?>">
        <div class="card border-dark mb-3" style="padding:20px;margin-top:-20px;border:none">
          <div class="card-body">
            <p class="card-text">
              To book an Appointment, Register yourself first by clicking the Register link
            </p>
          </div>
        </div>
      </th>
      <th style=" padding:50px;text-align:center ;">
      <img class="s" style="height: 200px; width: 60%;border-radius:60%;border:2px solid yellow" src="<?= base_url('vaccine\img\appointment.jpg'); ?>">
        <div class="card border-dark mb-3" style="padding:20px;margin-top:-20px;border:none">
          <div class="card-body">
            <p class="card-text">
             Get an Appointment by seaching your nearest Center and book your Slot
          </div>
        </div></th>

      <th style=" padding:50px;text-align:center;padding-right:100px">
      <img style="height: 200px; width: 60%;border-radius:50%;border:2px solid yellow;" src="<?= base_url('vaccine\img\ceritificate.jpg'); ?>">
        <div class="card border-dark mb-3" style="padding:20px;margin-top:-20px;border:none">
          <div class="card-body">
            <p class="card-text">
            Download your certificate from the dashboard section & wait for 2nd Dose
            </p>
          </div>
        </div></th>
        </div>
    </tr>
  </thead>
</table>

