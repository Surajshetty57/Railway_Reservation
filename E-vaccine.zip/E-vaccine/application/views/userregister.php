<style>
.border-class
{
  width:35%;
}
.form-group{
  padding-top: 10px;
}
label{
  padding-top:10px;
}
</style>
<?php include('common/header.php')?>
<div class="d-flex justify-content-center">
<div class="border-class" >
<div class="container">
  <div class="card border-dark mb-3" style="margin-top:30px;">
    <div class="card-body">
    <?php echo form_open('home/register');?>
      <form >
        <fieldset>
          <h2 style="font-family:monotype corsiva;font-size:45px;color:whitesmoke;text-decoration:underline;">Register !!!</h2>
          <div class="form-group"><b>
            <label > Full name</label>
            <?php echo form_input(['name'=>'fname','class'=>'form-control','placeholder'=>'Enter  Fullname','value'=>set_value('fname')]); ?>
	          <?php echo form_error('fname'); ?>
          </div>
          <div class="form-group">
            <label >Username</label>
              <?php echo form_input(['name'=>'uname','class'=>'form-control','placeholder'=>'Enter Username','value'=>set_value('uname')]); ?>
	            <?php echo form_error('uname'); ?>
          </div>
          <div class="form-group">
            <label for="dob">Date of birth</label>
            <?php echo form_input(['type'=>'date','name'=>'dob','class'=>'form-control','value'=>set_value('dob')]); ?>
	          <?php echo form_error('dob'); ?>
          </div>
          <div class="form-group">
           <label for="exampleSelect1">Gender</label>
            <select class="form-control" id="exampleSelect1" name="gender" vale="set_value(gender)">
            <option>Male</option>
            <option>Female</option>
            </select>
            <?php echo form_error('gender'); ?>
          </div>
          <div class="form-group">
            <label >Mobile number</label>
              <?php echo form_input(['type'=>'number','name'=>'mobile','class'=>'form-control','min'=>0,'placeholder'=>'Enter 10 digit Mobile number','value'=>set_value('mobile')]); ?>
	            <?php echo form_error('mobile'); ?>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Enter City</label>
            <?php echo form_input(['type'=>'text','name'=>'city','class'=>'form-control','placeholder'=>'Enter City','value'=>set_value('city')]); ?>
            <?php echo form_error('city'); ?>  
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <?php echo form_input(['type'=>'password','name'=>'pword','class'=>'form-control','placeholder'=>'Enter Password']); ?>
	          <?php echo form_error('pword'); ?>
          </div>
          <div class="form-group">
            <label for="password">Confirm Password</label>
            <?php echo form_input(['type'=>'password','name'=>'cpword','class'=>'form-control','placeholder'=>'Confirm Password']); ?>
	          <?php echo form_error('cpword'); ?>
          </div>
          <div style="margin-top:15px">
            <button type="submit" class="btn btn-primary" value="login">Submit</button>
            <button type="reset" class="btn btn-warning" >Cancel</button>
          </div><br>
          <a class="" href="<?= base_url('home/uslogin') ?>">Already  a member? LOGIN </a>
          </fieldset>
        </fieldset>
        </div>
      </form>
</div>
</div>
