<style>
  h1{
  color:whitesmoke;
  text-decoration:underline; margin-left:120px;
  font-family:Monotype Corsiva;
  
}
</style>
<?php include('common/header.php');?><br><br>

<div class="container">
<h1 style="">Centers Available </h1>
<br>
<div class="alert alert-dismissible alert-warning">
  <strong>Hey, </strong><a href="<?=('register')?>" class="alert-link">To book your slot please Register/Login yourself</a>.
</div>
<table class="table table-dark  " style="text-align:center;font-family:monotype corsiva;font-size:23px;margin-bottom:130px">
<thead>
<tr>
  <th scope="col">Center ID</th>
  <th scope="col">Center</th>
  <th scope="col">Vaccine</th>
  <th scope="col">Pincode</th>
  <th scope="col">District</th>
  <th scope="col">Date</th>
  <th scope="col">Time Slot</th>
</tr>
</thead>
<tbody>
<?php if(count($showslots)):?>
<?php foreach($showslots as $st): ?>
<tr class="table-active">
  <td><?php echo $st->c_id; ?></td>
  <td><?php echo $st->c_name; ?></td>
  <td><?php echo $st->vaccine_name; ?></td>
  <td><?php echo $st->Pincode; ?></td>
  <td><?php echo $st->city; ?></td>
  <td><?php echo $st->date; ?></td>
  <td><?php echo $st->time_slot; ?></td>
</tr>
</tbody>
<?php endforeach;?>
 <?php endif;?>

</table>
</div>