<style>
.border-class
{
  width:30%;
  margin-top:7%;
}
.form-group{
  padding: 10px;
}
</style>
<?php include('common/userdashboard.php')?>
<div class="d-flex justify-content-center">
  
<div class="border-class" >
<div class="container">
  <div class="card border-dark mb-3" style="margin-top:30px;">
    <div class="card-body">
    <?php echo form_open('user/availableslot');?>
      <form >
        <fieldset>
          <h2 style="font-family:Monotype Corsiva;font-size:45px;color:whitesmoke;text-decoration:underline;">Search By Pincode</h2>
         
          <div class="form-group">
          <label for="district">Pincode</label>
                <select class="form-control" id="exampleSelect" name="pincode"> 
                  <?php if(count($pin)):?>
                  <?php foreach($pin as $pi):?>
                  <option value=<?php echo $pi->pincode ?>><?php echo $pi->pincode ?> </option>
                  <?php endforeach;?>
                  <?php endif;?>
                </select><?php echo form_error('pincode'); ?>
            
          </div>
          <div class="form-group">
            <label for="dob">Date</label>
            <?php echo form_input(['type'=>'date','name'=>'date','class'=>'form-control','min'=>date('Y-m-d'),'value'=>set_value('date')]); ?>
	          <?php echo form_error('date'); ?>
          </div>
          <div style="padding:10px" class="form-group">
            <button type="submit" class="btn btn-primary" value="login">Search</button>
          </div>
        </fieldset>
        </div>
      </form>
</div>
</div>
</div>
       


