<style>
  h1{
  color:whitesmoke;
  text-decoration:underline;
  font-family:Monotype Corsiva; 
}
</style>
<?php include('common/userdashboard.php');?><br><br>
<div class="container">
<h1 style="font-size:55px;">Centers Available</h1>

<br>
<table class="table table-dark" style="text-align:center;font-family:monotype corsiva;font-size:23px;margin-bottom:130px">
<thead>
<tr>
  <th scope="col">Center ID</th>
  <th scope="col">Center</th>
  <th scope="col">Vaccine</th>
  <th scope="col">Pincode</th>
  <th scope="col">District</th>
  <th scope="col">Date</th>
  <th scope="col">Time Slot</th>
  <th scope="col">Action</th>
</tr>
</thead>
<tbody>
<?php if(count($showslots)):?>
<?php foreach($showslots as $st): ?>
<tr class="table-active">
  <td><?php echo $st->c_id; ?></td>
  <td><?php echo $st->c_name; ?></td>
  <td><?php echo $st->vaccine_name; ?></td>
  <td><?php echo $st->Pincode; ?></td>
  <td><?php echo $st->city; ?></td>
  <td><?php echo $st->date; ?></td>
  <td><?php echo $st->time_slot; ?></td>
  <td>
        <?php echo anchor("user/take_appointment/{$st->c_id}",'Get Appointment  ',['class'=>'btn btn-light','style'=>'font-size:25px;height:35px;margin-top:-5px;padding-top:0px;font-family:Monotype Corsiva']); ?>
    </td>
</tr>
</tbody>
<?php endforeach;?>
 <?php endif;?>

</table>
</div>