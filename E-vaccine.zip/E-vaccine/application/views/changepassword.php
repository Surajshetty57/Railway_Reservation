
<?php include('common/userdashboard.php');?>
<style>
.border-class
{
  width:30%;
  margin-top:7%;
}
.form-group{
  padding: 10px;
}
h2{
  color:whitesmoke;
  text-decoration:underline;
  font-family:Monotype Corsiva; 
}
</style>
<div class="d-flex justify-content-center">
<div class="border-class" >
<div class="container">
  <div class="card border-dark mb-3" style="margin-top:0px;">
    <div class="card-body">
        <?php echo form_open('user/changepassword');?>
        <form method="post" name="changepassword" action="<?php echo base_url('user/changepassword');?>" >
        <fieldset>
        <h2 style="font-size:50px">Change Password </h2>
            <div class="form-group"><b>
              <label for="username">Current Password</label>
              <?php echo form_input(['type'=>'password','name'=>'pword','class'=>'form-control','placeholder'=>'Enter Current Password']); ?>
	            <?php echo form_error('psword'); ?>
            </div>
            <div class="form-group">
              <label for="password">New Password</label>
              <?php echo form_input(['type'=>'password','name'=>'npword','class'=>'form-control','placeholder'=>'Enter new Password']); ?>
	            <?php echo form_error('npword'); ?>
            </div>
            <div class="form-group">
              <label for="password">Confirm New Password</label>
              <?php echo form_input(['type'=>'password','name'=>'confirmnpword','class'=>'form-control','placeholder'=>'Confirm new Password']); ?>
	            <?php echo form_error('confirmnpword'); ?>
            
            <button style="margin-top:15px" type="submit" class="btn btn-primary" value="Update">Update Password</button>
          </div>
        </fieldset>
        </div>
        </form>
      </div>
    </div>
  </div>
</div><br><br>