<style>
  h1{
    text-align:center;
    font-family:monotype corsiva;
    color:whitesmoke;  
    font-size:55px;
  }
</style>
<?php include('common/userdashboard.php');?><br>

<h1 style="margin-top:200px; ">
<b>Welcome <?php echo ucfirst($this->session->userdata('fname'));?></h1>
<h1> Book an Appointment and Get yourself Vaccinated</b></h1> <br>
</div>