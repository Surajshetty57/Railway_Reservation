<style>
    .border-class
{
  width:60%;
  margin-top:33px
}
h2{
  color:whitesmoke;
  text-decoration:;
  font-family:monotype corsiva;
  
}
@media print {
    #with_print {
        display: none;
    }
}
</style>

<?php include('common/userdashboard.php');?>
<div class="d-flex justify-content-center " style=" ">
  <div class="border-class" >
  <div class="container" >
  <div class="card border-success mb-3" >
<div class="shadow-lg p-4">
  <div class="card-header bg-primary">
  <h3 style="text-align:center;font-size:30px;color:white;font-family:monotype corsiva;" >Vaccination Certificate</h3></div><br><br>
    <div style="background-color:" id="content">
     <table class="table table-dark">
  <thead>
  <?php if($show_cert==true):?>
    <tr>
    <th scope="" style="font-family:monotype corsiva;"><h3 name="c_name"style="font-size:30px "> <?php echo $show_cert->c_name;?> - <?php echo $show_cert->city;?></h3><br>
    
       <h4 name="booked_by"style="font-size:30px " > <?php echo $show_cert->booked_by; ?></h4>
       <p name="user_id"  style="font-size:20px" >User ID : <?php echo $show_cert->user_id; ?></p><br>
       <h4 name="vaccine_name" style="font-size:30px " >Vaccine Name : <?php echo $show_cert->vaccine_name; ?></h4><br>
        <h4 name="date" style="font-size:30px" >Date : <?php echo $show_cert->date; ?></h4><br> 
       <h4 name="time_slot" style="font-size:30px" >Time Slot :  <?php echo $show_cert->time_slot; ?></h4><br>
</th>
  <?php else:?>
        <script>alert("You haven't taken Vaccination yet");document.location='http://localhost/E-vaccine/user/dashboard';</script>
  <?php endif;?>
    </tr>
  </thead>
  </table>
  
  </div>
  <div id="editor" style="margin-top:15px">
      <button  onclick="window.print()" type="submit" class="btn btn-primary" value="login">Download</button>
  </div>
  </div>
</div>
<br>