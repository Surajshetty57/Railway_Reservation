
<style>
    .border-class
{
  width:60%;
}
h2{
  color:whitesmoke;
  text-decoration:underline; margin-left:120px;
  font-family:Monotype Corsiva;
  
}

</style>
<?php include('common/userdashboard.php');?><br><br>
<div class="container">
<h2 style="font-size:50px">Personal Details</h2><br>
</div>
<div class="d-flex justify-content-center">
<div class="border-class" >
<div class="container">
  <div class="card border-success mb-3" style="margin-top:30px;">
    <div class="card-body">
      <?php echo form_open("user/details");?>
<table class="table table-dark" style="font-family:Monotype Corsiva;font-size:30px;">
  <thead>
    <tr>
      <th scope="col">Name</th>
      <th scope="row"><?php echo ucfirst($data['fname'])?></th>
    </tr>
    <tr>
      <th scope="col">User Name</th>
      <th scope="row"><?php echo ucfirst($data['uname'])?></th>
    </tr>
    <tr>
      <th scope="col">Date of Birth</th>
      <th scope="row"><?php echo $data['dob']?></th>
    </tr>
    <tr>
      <th scope="col">Gender</th>
      <th scope="row"><?php echo ucfirst($data['gender'])?></th>
    </tr>
    <tr>
      <th scope="col">Mobile</th>
      <th scope="row"><?php echo ucfirst($data['mobile'])?></th>
    </tr>
    <tr>
      <th scope="col">City</th>
      <th scope="row"><?php echo ucfirst($data['city'])?></th>
    </tr>
  </thead>
</table>
</div>
</div>
</div>
</div><br><br>


