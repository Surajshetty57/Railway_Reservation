<style>
    .border-class
{
  width:30%;
}
h2{
  color:whitesmoke;
  text-decoration:underline;
  font-family:Monotype Corsiva;
}
label{
  margin-top:10px;
}
</style>

<?php include('common/userdashboard.php');?>
<div class="d-flex justify-content-center">
<div class="border-class" >
<div class="container">
  <div class="card border-dark mb-3" style="margin-top:30px;">
    <div class="card-body">
        <?php echo form_open("user/take_appointment/{$showslots->c_id}");?>
          <form method="post" name="reservetrain" action="<?php echo base_url('bookslots');?>">
            <fieldset>
            <h2 style="font-size:40px">Appointment Confirmation</h2><br>
            
            <div class="form-group"><b>
              <label for="Booked By">Booked By</label>
              <?php echo form_input(['name'=>'booked_by','class'=>'form-control','readonly'=>"value",'value'=>set_value('fname',ucfirst($data['fname']))]); ?>
            </div>
            <div class="form-group">
              <label for="User ID">User ID</label>
              <?php echo form_input(['name'=>'user_id','class'=>'form-control','readonly'=>"value",'value'=>set_value('user_id',$data['user_id'])]); ?>
            </div>
            <div class="form-group">
              <label for="center">Center</label>
              <?php echo form_input(['name'=>'c_name','class'=>'form-control','readonly'=>"value",'value'=>set_value('c_name',$showslots->c_name)]); ?>
            </div>
            <div class="form-group">
              <label for="Vaccine Name">Vaccine Name</label>
              <?php echo form_input(['name'=>'vaccine_name','class'=>'form-control','readonly'=>"value",'value'=>set_value('vaccine_name',$showslots->vaccine_name)]); ?>
            </div>
            <div class="form-group">
              <label for="City">City</label>
              <?php echo form_input(['name'=>'city','class'=>'form-control','readonly'=>"value",'value'=>set_value('city',$showslots->city)]); ?>
            </div>
            <div class="form-group">
              <label for="date">Date</label>
              <?php echo form_input(['name'=>'date','class'=>'form-control','readonly'=>"value",'value'=>set_value('date',$showslots->date)]); ?>
            </div>
            <div class="form-group">
              <label for="time slot">Time Slot</label>
              <?php echo form_input(['name'=>'time_slot','class'=>'form-control','readonly'=>"value",'value'=>set_value('time_slot',$showslots->time_slot)]); ?>
            </div>
              <button style="margin-top:15px" type="submit" class="btn btn-primary" value="ConfirmApointment">Confirm Appointment</button>
              <?php echo anchor("user/dashboard",'Cancel ',['class'=>'btn btn-warning','style'=>'margin-top:15px' ]);?>

              </fieldset>
              
      </div>
    </div>
  </div>
</div><br><br>