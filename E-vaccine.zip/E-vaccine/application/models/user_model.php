<?php 
class user_model extends CI_Model{
   
    public function user_validate($pdata)
    {
        return ($this->db->insert('user', $pdata)) ? $this->db->insert_id() : false; // return insert_id if successful else return false
    }
    public function user_validation($uname,$pword)
    {
       $checkuser=$this->db->where(['uname'=>$uname,'pword'=>$pword])
                        ->get('user');
       if($checkuser->num_rows()>0){
           return $checkuser->row();
       }
                     
    }
    public function getcities()
    {
        $cities=$this->db->get('cities');
        if($cities->num_rows()>0){
            return $cities->result();
        }
    }
    public function getpincode()
    {
        $pin=$this->db->get('pincode');
        if($pin->num_rows()>0){
            return $pin->result();
        }
    }
    public function fetchdetails($user_id = null)
    {   
        if($user_id)
        {   
            $data="SELECT * FROM user WHERE user_id=?";
            $query=$this->db->query($data,array($user_id));
            $result=$query->row_array();
            return $result;
        }
    }
    public function view_slots_city($city,$date)
    {
       $this->db->select('*')->where(['centers.city'=>$city,'centers.date'=>$date]);
        return $this->db->get('centers')->result();
        
    }
    public function view_slots_pin($pin,$date)
    {
       $this->db->select('*')->where(['centers.pincode'=>$pin,'centers.date'=>$date]);
        return $this->db->get('centers')->result();
        
    }
    public function get_slot_details($c_id)
    {
        $this->db->select('*');
        $this->db->from('centers');
        $this->db->where(['centers.c_id'=>$c_id]);
        $showslots=$this->db->get();
        return $showslots->row();
    }
    public function bookslots($data,$c_id)
    {
        return $this->db->insert('appointment',$data);
    }
    public function fetch_slot($user_id = null)
    {   
        if($user_id)
        {   
            $print="SELECT * FROM user ORDER By user_id desc";
            $query=$this->db->query($print,array($user_id));
            $result=$query->row_array();
            return $result;
        }
    }
    public function update_userdata($user_id,$data)
    {
        $this->db->set($data);
        $this->db->where('user_id',$user_id);
        $this->db->update('user');
        if($this->db->affected_rows()>0)
        return true;
        else
        return false;
    }
    public function checkoldpword($user_id,$old_password)
    {
        $this->db->where('user_id',$user_id);
        $this->db->where('pword',$old_password);
        $query=$this->db->get('user');
        if($query->num_rows()>0){
            return true;
          }  else{
            return false;
        }
    }
    public function get_certificate($user_id = null)
    {   
        if($user_id)
        {   
            $certificate="SELECT * FROM verified ORDER By ver_id desc";
            $query=$this->db->query($certificate,array($user_id));
            $result=$query->row_array();
            return $result;
        }
    }
    public function certificate_details($user_id)
    {
        $this->db->select('*');
        $this->db->from('verified');
        $this->db->where(['verified.user_id'=>$user_id]);
        $show_cert=$this->db->get();
        return $show_cert->row();
    }
    public function send_feedback($feedback)
    {
        return $this->db->insert('feedback',$feedback);
    }
}
?>