<?php
class dept_model extends CI_model
{  
    public function dept_validate($username,$password)
    {
        $checkdept=$this->db->where(['username'=>$username,'password'=>$password])
                        ->get('dept');
        if($checkdept->num_rows() > 0){
            return $checkdept->row();
           // return TRUE;
        }else{
            return False;
        }
    }
    public function feedback()
    {
        $this->db->select('*');
        $this->db->from('feedback');
        $fback=$this->db->get();
        return $fback->result();
    } 
    public function getcities()
    {
        $cities=$this->db->get('cities');
        if($cities->num_rows()>0){
            return $cities->result();
        }
    }
    public function getpincode()
    {
        $pin=$this->db->get('pincode');
        if($pin->num_rows()>0){
            return $pin->result();
        }
    }
    public function newcenter($data)
    {
        return $this->db->insert('centers',$data);   
    }
    public function addcities($addcity)
    {
        return $this->db->insert('cities',$addcity);
    }
    public function ver_appointments(){
        $this->db->select('*');
        $this->db->from('appointment');
        $appointments=$this->db->get();
        return $appointments->result();
    }
    public function cancel($reference_id)
    {
        return $this->db->delete('appointment',['reference_id'=>$reference_id]);
    }
    public function saved($reference_id)
    {
        $this->db->query("INSERT INTO verified SELECT * FROM appointment WHERE reference_id = $reference_id;");
        return $this->db->query("DELETE FROM appointment WHERE reference_id = $reference_id;"); 
        
    }
    
}
?>





